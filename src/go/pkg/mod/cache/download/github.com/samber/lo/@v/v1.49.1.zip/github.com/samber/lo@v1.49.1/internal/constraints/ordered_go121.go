//go:build go1.21

package constraints

import (
	"cmp"
)

type Ordered = cmp.Ordered
