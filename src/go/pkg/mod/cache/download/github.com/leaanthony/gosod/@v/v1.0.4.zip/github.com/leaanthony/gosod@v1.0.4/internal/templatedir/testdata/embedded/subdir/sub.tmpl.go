package subdir

// This should be included in the test output
// My name is {{.Name}}
