package dirname
