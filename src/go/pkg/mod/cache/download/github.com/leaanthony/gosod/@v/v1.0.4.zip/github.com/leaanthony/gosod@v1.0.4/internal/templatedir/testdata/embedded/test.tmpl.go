package embedded

// This is test data for using embed.FS for scaffolding

var name = "{{.Name}}"
