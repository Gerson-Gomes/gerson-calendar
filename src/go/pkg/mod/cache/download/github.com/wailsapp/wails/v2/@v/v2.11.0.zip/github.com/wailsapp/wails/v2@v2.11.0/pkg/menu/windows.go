package menu

/*
// DefaultWindowsMenu returns a default menu including the default
// Application and Edit menus. Use `.Append()` to add to it.
func DefaultWindowsMenu() *Menu {
	return NewMenuFromItems(
		FileMenu(),
		EditMenu(),
		WindowMenu(),
	)
}
*/
