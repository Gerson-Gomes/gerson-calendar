package template

import (
	"embed"
)

//go:embed base
var Base embed.FS
