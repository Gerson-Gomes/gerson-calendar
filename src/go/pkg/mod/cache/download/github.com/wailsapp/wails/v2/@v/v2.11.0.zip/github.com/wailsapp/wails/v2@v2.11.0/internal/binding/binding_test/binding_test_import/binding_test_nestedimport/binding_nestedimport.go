package binding_test_nestedimport

type A struct {
	A string `json:"A"`
}
