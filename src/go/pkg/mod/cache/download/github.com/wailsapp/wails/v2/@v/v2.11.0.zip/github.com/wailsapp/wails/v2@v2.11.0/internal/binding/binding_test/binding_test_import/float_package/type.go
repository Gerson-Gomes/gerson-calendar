package float_package

type SomeStruct struct {
	Name string `json:"string"`
}
