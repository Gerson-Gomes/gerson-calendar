## Tray

Place any PNG file in this directory to be able to use them as tray icons.
The name of the filename will be the ID to reference the image.

Example:

* `mypic.png` - May be referenced using `runtime.Tray.SetIcon("mypic")` 
