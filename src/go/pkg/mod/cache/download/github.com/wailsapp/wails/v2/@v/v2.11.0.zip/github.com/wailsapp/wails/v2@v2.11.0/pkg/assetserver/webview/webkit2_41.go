//go:build linux && webkit2_41

package webview

const Webkit2MinMinorVersion = 41
