package internal

import _ "embed"

//go:embed version.txt
var Version string
